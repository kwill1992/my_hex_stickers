* [ ] I have converted fonts to outlines in the `.svg`
* [ ] My PNG has dimensions 2521 x 2911
